FAISAL ANSARI — HTML / CSS PORTFOLIO

1. Extract the whole ZIP.
2. Open index.html in Chrome, Edge, Firefox or Safari.

No Node.js, npm or React installation is needed. Keep all files and the assets folder together.

index.html — page structure and text
style.css — design and responsive styles
script.js — filters, project detail dialogs, gallery and copy-email action
assets/ — images, resume and web-optimized Samarra PDF

To edit project details, update script.js; update matching project card text in index.html as needed.
Google Fonts load from the internet; local fallback fonts work offline.
For hosting, upload the contents of this folder to any static website host.

Exported 11 November 2026. This is a standalone edition of the portfolio; editing these files does not update the hosted Site.
